package com.huntery.purplepanel;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
public class MainActivity extends Activity {
  int bg=Color.rgb(16,11,24), panel=Color.rgb(31,21,45), purple=Color.rgb(181,108,255);
  LinearLayout content;
  public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(20,13,32)); getWindow().setNavigationBarColor(Color.rgb(20,13,32));
    ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(bg);
    content=new LinearLayout(this); content.setOrientation(1); content.setPadding(dp(20),dp(24),dp(20),dp(28)); scroll.addView(content); setContentView(scroll);
    content.addView(txt("Yamal hack",28,Color.WHITE,true));
    TextView sub=txt("MATRESHKA RP • PURPLE EDITION",12,Color.rgb(190,170,210),false); sub.setPadding(0,dp(5),0,dp(20)); content.addView(sub);
    LinearLayout notice=card(); notice.addView(txt("Демонстрационный интерфейс. Переключатели меняют только состояние меню и не воздействуют на Матрешка RP или её серверы.",13,Color.rgb(230,215,245),false)); content.addView(notice);
    section("ФУНКЦИИ • ДЕМО");
    String[] items={"Телепорт (макет)","Аим от 3 лица (макет)","Аим от 1 лица (макет)","Хитбоксы 20x (макет)","Спидхак 5x (макет)","Аир брейк 30 м/с (макет)","Джетпак (макет)","Самоубийство (макет)"};
    for(String item:items) toggle(item);
    TextView foot=txt("YAMAL HACK • v1.0",11,Color.rgb(145,120,165),true); foot.setGravity(Gravity.CENTER); foot.setPadding(0,dp(26),0,0); content.addView(foot);
  }
  void section(String s){TextView t=txt(s,12,purple,true);t.setPadding(dp(4),dp(22),0,dp(8));content.addView(t);}
  void toggle(String s){
    LinearLayout row=card(); row.setGravity(Gravity.CENTER_VERTICAL);
    row.addView(txt(s,14,Color.WHITE,false),new LinearLayout.LayoutParams(0,dp(48),1));
    Switch sw=new Switch(this); sw.setOnCheckedChangeListener((v,on)->Toast.makeText(this,s+(on?" — ВКЛ":" — ВЫКЛ"),Toast.LENGTH_SHORT).show()); row.addView(sw);
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(9);content.addView(row,lp);
  }
  LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setPadding(dp(15),dp(11),dp(14),dp(11));GradientDrawable d=new GradientDrawable();d.setColor(panel);d.setCornerRadius(dp(16));d.setStroke(dp(1),Color.rgb(65,43,87));l.setBackground(d);return l;}
  TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
}
