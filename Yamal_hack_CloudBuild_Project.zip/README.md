# Yamal hack — Android demo UI

Standalone Android demo panel. The game-like controls are UI mockups only: they do not modify Matreshka RP, interact with its servers, manipulate game memory, or bypass anti-cheat.

## Build APK using GitHub on your phone
1. Create an empty GitHub repository.
2. Upload the CONTENTS of this folder to the repository (not the ZIP itself).
3. Open the Actions tab. Select "Build Yamal hack APK"; run the workflow if needed.
4. Open the completed run and download the artifact "Yamal-hack-debug-apk".
5. Extract that artifact ZIP. It contains app-debug.apk.
